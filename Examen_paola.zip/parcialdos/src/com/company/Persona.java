package com.company;

public class Persona {
    private String nombre; 
    private String ine;
    private int edad;
    private String direccion;
    private String telefono;


    public Persona (String nombre, String ine, int edad, String direccion, String telefono){
        this.nombre=nombre;
        this.ine=ine;
        this.edad=edad;
        this.direccion=direccion;
        this.telefono=telefono;
    }

    public Persona(){

    }
    public int getEdad(){
        return edad;
    }
    public String getNombre(){
        return nombre;
    }

    public String getIne(){
        return ine;
    }
    public String getDireccion(){
        return direccion;
    }
    public String getTelefono(){
        return telefono;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setIne(String ine){
        this.ine=ine;
    }
    public void setEdad(int edad){
        this.edad=edad;
    }
    public void setDireccion(String direccion){
        this.direccion=direccion;
    }
    public void setTelefono(String telefono){
        this.telefono=telefono;
    }
    @Override
    public String toString(){
        return super.toString()+ "Nombre de la persona "+nombre +"\n" +"Ine: "+ine+"\n"+"Edad: "+edad+"\n"+ "Dirección: "+direccion+"\n"+"Telefono: "+telefono+"\n";
    }


}


