package com.company;

public class Cuenta extends Persona {

    private String titular ;
    private String numcuenta;
    private String banco ;
    private double saldo;
    private double cantidad;
    private double retiro;

    public Cuenta(String nombre, String ine, int edad, String direccion, String telefono,String titular, String numcuenta,String banco,double saldo, double cantidad, double retiro) {
        super(nombre, ine, edad, direccion,telefono);
        this.numcuenta=numcuenta;
        this.titular=titular;
        this.banco=banco;
        this.saldo=saldo;
        this.cantidad=cantidad;
        this.retiro=retiro;

    }
    public Cuenta(String titular, String numcuenta,String banco, double cantidad,double retiro,double saldo) {
        this.numcuenta=numcuenta;
        this.titular=titular;
        this.banco=banco;
        this.saldo=saldo;
        this.cantidad=cantidad;
        this.retiro=retiro;

    }

    public Cuenta(){
        super();
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getNumcuenta() {
        return numcuenta;
    }

    public void setNumcuenta(String numcuenta) {
        this.numcuenta = numcuenta;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public double getRetiro() {
        return retiro;
    }

    public void setRetiro(double retiro) {
        this.retiro = retiro;
    }

    public void depositar(){
        if(cantidad<0){
            System.out.println("***Cantidad incorrecta la cantidad a depositar debe ser mayor***\n");

        }else{
            System.out.println("****Operación de deposito realizada****");
            System.out.println("Cantidad depositada: $"+cantidad);
            System.out.println("           Información");

            System.out.println("*****************************");
            System.out.println(resumenCliente());
            System.out.println("*****************************\n\n\n");
        }
    }
    public void ConsultarSaldo(){
        if(numcuenta.length()<10){
            System.out.println("*** Cuenta no aceptada, vuelva a intentarlo***");
        }else if(numcuenta.length()>10){
            System.out.println("***Cuenta no aceptada, vuelva a intentarlo***");
        }else{
            System.out.println("****Operación de consultar saldo****");
            System.out.println("Tú saldo es de: "+ saldo);
            System.out.println("           Información");
            System.out.println("*****************************");

            System.out.println(resumenCliente());
            System.out.println("*****************************");

        }

    }
    public void retirar() {
        if (saldo < retiro) {
            System.out.println("\n\n\n***No se puede realizar el retiro, cuenta con poco saldo***");

        } else if(retiro<0){
           System.out.println("\n\n\n\n***No se puede realizar dicha operación***");

        }else{
            saldo=saldo-retiro;
            System.out.println("\n\n\n\n****Operación de retiro realizada****");

            System.out.println("           Información");
            System.out.println("Usted retiro: "+retiro+"\n"+"Su saldo actual es de: "+saldo);
            System.out.println("*****************************");

            System.out.println(resumenCliente());
            System.out.println("*****************************");
        }
    }

    private String resumenCliente(){
        return "Nombre de la persona "+getNombre() +"\n" +"Ine: "+getIne()+"\n"+"Edad: "+getEdad()+"\n"+
                "Dirección: "+getDireccion()+"\n"+"Telefono: "+getTelefono()+"\n";
    }







}
