package com.company;

public class Main {

    public static void main(String[] args) {
        Cuenta cuenta1 =new Cuenta();
        cuenta1.setNombre("Pablo");
        cuenta1.setIne("iuweoiwe");
        cuenta1.setEdad(20);
        cuenta1.setDireccion("independencia");
        cuenta1.setTelefono("1290389213");
        cuenta1.setTitular("jefe");
        cuenta1.setNumcuenta("12435234189");
        cuenta1.setBanco("asfasf");
        cuenta1.setSaldo(13.0);
        cuenta1.setCantidad(-2000.7);
        cuenta1.setRetiro(-100.0);
        cuenta1.depositar();
        cuenta1.ConsultarSaldo();
        cuenta1.retirar();


    }
}
